import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.title("Contagem de Produtos por Segmento")

try:
    df = pd.read_csv('MS_Financial Sample.csv', delimiter=';', on_bad_lines='skip')
except FileNotFoundError:
    st.error("Arquivo 'MS_Financial Sample.csv' não encontrado. Verifique o caminho.")
    st.stop()

df.columns = [
    'Segmento', 'País', 'Produto', 'Faixa de Desconto', 'Unidades Vendidas',
    'Preço de Fabricação', 'Preço de Venda', 'Vendas Brutas', 'Descontos',
    'Vendas', 'CPV', 'Lucro', 'Data', 'Número do Mês', 'Nome do Mês', 'Ano'
]

# Remove valores nulos na coluna 'Segmento' só para garantir
df = df.dropna(subset=['Segmento'])

# Contagem de produtos por segmento
contagem_segmento = df['Segmento'].value_counts()

if contagem_segmento.empty:
    st.warning("Não há dados para mostrar.")
else:
    fig, ax = plt.subplots(figsize=(10,6))
    contagem_segmento.plot(kind='bar', color='orange', ax=ax)
    ax.set_title('Quantidade de Produtos por Segmento')
    ax.set_xlabel('Segmento')
    ax.set_ylabel('Quantidade')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    st.pyplot(fig)
